public class SyntaxPracticeSep2
{
    public static void main(String[] args) {
        System.out.print("AP"); // AP \n CS \n A
        System.out.println();
        System.out.println("CS");
        System.out.print("A");
        
        System.out.print("\nI do not fear computers. ");
        System.out.println("I fear the lack of them.");
        System.out.println("--Isaac Asimov");
        
        System.out.print("*");
        System.out.println("**");
        System.out.println("***");
        System.out.print("****");
    }
}
